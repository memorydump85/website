/***************
*  STRUCTS.H   *
***************/

#define __STRUCTS_H

typedef unsigned int UINT;
typedef unsigned char UCHAR;

/*-------------------------------------------------------------------------*/

// The following structure is used by getSVGAInfo

struct VgaInfoBlock
{
	char 	 	signature[4];		// VESA
	int  		version;            // SVGA bios version
	char far 	*OEMname;           // Name
	long 		capabilities;       // Capabilities of device
	unsigned far*modes;             // -1 terminated list of available modes
	int 		totalMemory;		// In 64 Kb blocks
	char 		buffer[236];		// Unused
};

/*-------------------------------------------------------------------------*/

// The following structure is used by getSVGAModeInfo

struct VgaModeInfoBlock
{
	UINT  modeAttributes;
	UCHAR winAAttributes;
	UCHAR winBAttributes;
	UINT  windowGranularity;
	UINT  winSize;
	UINT  winASegment;
	UINT  winBSegment;
	void (far *WinFuncPtr)(void);
	UINT  bytesPerScanLine;
	UINT  xResolution;
	UINT  yResolution;
	UCHAR xCharSize;
	UCHAR yCharSize;
	UCHAR numberOfPlanes;
	UCHAR bitsPerPixel;
	UCHAR numberOfBanks;
	UCHAR memoryModel;
	UCHAR bankSize;
	UCHAR numberOfImagePages;
	UCHAR reserved1;

// Direct color fields
	
	UCHAR redMaskSize;
	UCHAR redFieldPosition;
	UCHAR greenMaskSize;
	UCHAR greenFieldPosition;
	UCHAR blueMaskSize;
	UCHAR blueFieldPosition;
	UCHAR reservedMaskSize;
	UCHAR reservedFieldPosition;
	UCHAR directColorModeInfo;
	UCHAR reserved2[216];
};

/*-------------------------------------------------------------------------*/

// Constants for memoryModel field

#define memTextMode 0
#define memCGA 1
#define memHercules 2
#define mem4Plane 3
#define memPackedPixel 4
#define memNoChain256 5
#define memRGB 6
#define memYUV 7

/*-------------------------------------------------------------------------*/

// The following structure is used by get/set LogicalScanLineLen

struct LogicalScanLineLenInfo
{
	unsigned bytesPerScanLine;
	unsigned pixelsPerScanLine;
	unsigned maxScanLines;
};

/*-------------------------------------------------------------------------*/

// The following structures are used by Color functions

struct RGBFieldInfo
{
	unsigned char rPos, rSize;
	unsigned char gPos, gSize;
	unsigned char bPos, bSize;
};


typedef struct VgaInfoBlock VgaInfoBlock;
typedef struct VgaModeInfoBlock VgaModeInfoBlock;
typedef struct LogicalScanLineLenInfo LogicalScanLineLenInfo;
typedef struct LogicalScanLineLenInfo ScanLineInfo;
typedef struct RGBFieldInfo RGBFieldInfo;