/***************
*      MEM.H   *
***************/

#define __MEM_H

#define winA 0
#define winB 1

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

void (far *_pWinFunc)(void);
// pointer to function used to move the memory window position instead of
// using interrupts

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

void readUsing(unsigned n);
void writeUsing(unsigned n);

int setMemWindowPos_ptr(unsigned pos, unsigned window);
unsigned getMemWindowPos_ptr(unsigned char window);

int setMemWindowPos_ptrO();
int setMemWindowPos_intrO();

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

void readUsing(unsigned n)
{
	_winRNum = n;
	if(n==winA) _winRSeg = _winASeg; else _winRSeg = _winBSeg;
	_winRPos = getMemWindowPos(n);
}

/*-------------------------------------------------------------------------*/

void writeUsing(unsigned n)
{
	_winWNum = n;
	if(n==winA) _winWSeg = _winASeg; else _winWSeg = _winBSeg;
	_winWPos = getMemWindowPos(n);
}

/*-------------------------------------------------------------------------*/

#pragma warn -rvl

int setMemWindowPos_ptr(unsigned pos, unsigned window)
{

// This routine is in assembly for performance
// reasons

	asm {
			mov ax, 0x4F05		// Interrupt requirements
			mov bx, [window]	// bh = 0, bl = window
								// That is why window is an uint here
			mov dx, [pos]       // requirement
	}
		
		(*_pWinFunc)();         // intsead of generating interrupt

								// Value in ax is automatically returned
}

/*-------------------------------------------------------------------------*/

unsigned getMemWindowPos_ptr(unsigned char window)
{
	_AX = 0x4F05;
	_BH = 1;
	_BL = window;
	(*_pWinFunc)();				// intsead of generating interrupt

	biosStatus = _AX;
	return _DX;
}

/*-------------------------------------------------------------------------*/

int setMemWindowPos_ptrO()
{

// This routine is in assembly for performance
// reasons

// Assumes DX = position, BX = window

	asm mov ax, 0x4F05		// Interrupt requirements
		
	(*_pWinFunc)();         // intsead of generating an interrupt
}

/*-------------------------------------------------------------------------*/

int setMemWindowPos_intrO()
{

// This routine is in assembly for performance
// reasons

// Assumes DX = position, BX = window

	asm mov ax, 0x4F05		// Interrupt requirements

	geninterrupt(0x10);     // intsead of generating an interrupt
}

#pragma warn +rvl