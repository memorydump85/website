/***************
*      ATF.H   *
***************/

#define __ATF_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

struct atfCompareBlock
{
	unsigned xRes, yRes;
	unsigned char bitsPerPixel;
} Search;

// 'Search' is used along with atfCompare

/****************************************************************************
								CONSTANTS   
****************************************************************************/

#define NOT_DECIDED 0xFFFF
// Return value of an atf specifying that it has not decided the mode

#define FINAL_DECISION 0xFFFF
// Value of the modeNumber parameter when it is asked to return its
// Final decision

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

unsigned atfMaxResolution (unsigned modeNumber, VgaModeInfoBlock far* b);
unsigned atfMaxColor (unsigned modeNumber, VgaModeInfoBlock far* b);
unsigned atfCompare (unsigned modeNumber, VgaModeInfoBlock far* b);
unsigned atfMaxResolutionForColor (unsigned modeNumber, VgaModeInfoBlock far* b);

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

unsigned atfMaxResolution (unsigned modeNumber, VgaModeInfoBlock far* b)
{
	static unsigned xRes=0, yRes=0;
	static unsigned char bpp=0;
	static unsigned selectedMode=0;

	// For final call
	if( modeNumber == FINAL_DECISION ) return selectedMode;

	// If the mode is not supported in the current hardware configuration
	// you can just ignore it
	if(!(b->modeAttributes & 0x0001)) return NOT_DECIDED;
	
	// If resolution is greater select new mode
	if( (b->xResolution > xRes) || (b->yResolution > yRes) )
	{
		xRes = b->xResolution;
		yRes = b->yResolution;
		bpp = b->bitsPerPixel;
		selectedMode = modeNumber;

		goto atfMREnd;	// After the above code is executed the following
						// if construct will always be true
	}

	// If resolution is same with greater color depth then select mode
	if( (b->xResolution == xRes) || (b->yResolution == yRes) )
	{
		if(b->bitsPerPixel > bpp)
		{
			bpp = b->bitsPerPixel;			
			selectedMode = modeNumber;
		}
	}

atfMREnd:

	return NOT_DECIDED;
}

unsigned atfMaxColor (unsigned modeNumber, VgaModeInfoBlock far* b)
{
	static unsigned xRes=0, yRes=0;
	static unsigned char bpp=0;
	static unsigned selectedMode=0;

	// For final call
	if( modeNumber == FINAL_DECISION ) return selectedMode;
	
	// If the mode is not supported in the current hardware configuration
	// you can just ignore it
	if(!(b->modeAttributes & 0x0001)) return NOT_DECIDED;
	
	// If color is greater select new mode
	if( b->bitsPerPixel > bpp )
	{
		xRes = b->xResolution;
		yRes = b->yResolution;
		bpp = b->bitsPerPixel;
		selectedMode = modeNumber;

		goto atfMCEnd;	// After the above code is executed the following
						// if construct will always be true
	}

	// If color depth is same with greater color depth then select mode
	if( b->bitsPerPixel == bpp )
	{
		if( (b->xResolution > xRes) || (b->yResolution > yRes) )
		{
			xRes = b->xResolution;
			yRes = b->yResolution;
			selectedMode = modeNumber;
		}
	}

atfMCEnd:

	return NOT_DECIDED;
}

unsigned atfCompare (unsigned modeNumber, VgaModeInfoBlock far* b)
{

	// For final call, this occurs only no mode has been able to meet the reuirements.
	// This means you just can't make a decision
	if( modeNumber == FINAL_DECISION ) return NOT_DECIDED;

	// If the mode is not supported in the current hardware configuration
	// you can just ignore it
	if(!(b->modeAttributes & 0x0001)) return NOT_DECIDED;
	
	if (
			(b->xResolution == Search.xRes) &&
			(b->yResolution == Search.yRes) &&
			(b->bitsPerPixel == Search.bitsPerPixel)
	   )

		return modeNumber;

	else return NOT_DECIDED;
}

unsigned atfMaxResolutionForColor (unsigned modeNumber, VgaModeInfoBlock far* b)
{
	static unsigned xRes=0, yRes=0;
	static unsigned selectedMode=0;

	// For final call
	if( modeNumber == FINAL_DECISION ) return selectedMode;

	// If the mode is not supported in the current hardware configuration
	// you can just ignore it
	if(!(b->modeAttributes & 0x0001)) return NOT_DECIDED;
	
	// If resolution is greater with required color depth select new mode
	if( 
			((b->xResolution > xRes) || (b->yResolution > yRes)) &&
			(b->bitsPerPixel == Search.bitsPerPixel)
	  )
	{
		xRes = b->xResolution;
		yRes = b->yResolution;
		selectedMode = modeNumber;
	}

	return NOT_DECIDED;
}