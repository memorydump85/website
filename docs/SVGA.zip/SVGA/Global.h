/***************
*   GLOBAL.H   *
***************/


#define __GLOBAL_H

// This file contains external declarations for all global variables
// So that all variables will be visible even if files are included
// in a random order

// SvgaBios.h
	extern unsigned biosStatus;
	
// Svag.h
	extern 	unsigned _prevMode;

// Draw.h
	extern 	int (* _pSetMemWindowPos)(unsigned, unsigned);
	extern	int (* _pSetMemWindowPosO)();
	extern 	unsigned (* _pGetMemWindowPos)(unsigned char);
	extern 	void (* pPutPixel)(unsigned, unsigned, unsigned long);
	extern 	unsigned _bytesPerScanLine;
	extern 	unsigned _wndRPos, _wndWPos;
	extern 	unsigned _xRes, _yRes;
	extern 	unsigned _bitsPerPixel;

// Wrapper.h
	extern 	unsigned _width;
	extern 	unsigned actPage;
	extern 	unsigned _visPage;

// pix.h
	extern 	unsigned char transparency;
	extern 	unsigned scale;
	extern 	float rotation;
	extern 	unsigned char _granCorrection;

	extern 	unsigned _winASeg;
	extern 	unsigned _winBSeg;
	extern 	unsigned _winWSeg;
	extern 	unsigned _winRSeg;

	extern 	unsigned _winWNum;
	extern 	unsigned _winRNum;

	extern 	unsigned _winWPos;
	extern 	unsigned _winRPos;

// mem.h
	extern 	void (far *_pWinFunc)(void);