/***************
*     SVGA.H   *
***************/

#ifndef __GLOBAL_H
	#include "global.h"
#endif

#ifndef __SVGABIOS_H
	#include "svgabios.h"
#endif

#ifndef __DRAW_H
	#include "draw.h"
#endif

#ifndef __WRAPPER_H
	#include "wrapper.h"
#endif

#ifndef __PIX_H
	#include "pix.h"
#endif

#ifndef __MEM_H
	#include "mem.h"
#endif

#ifndef __ATF_H
	#include "atf.h"
#endif


#define __SVGA_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

unsigned _prevMode;
//	The _prevMode is used to store the current video mode when setting the
//	video mode

/****************************************************************************
								CONSTANTS   
****************************************************************************/

// Mode constants

#define _320x200_HI 0x10E
#define _320x200_TRUE 0x10F

#define _640x480_256 0x101
#define _640x480_HI 0x111
#define _640x480_TRUE 0x112

#define _800x600_16 0x102
#define _800x600_256 0x103
#define _800x600_HI 0x114
#define _800x600_TRUE 0x115

#define _1024x768_16 0x104
#define _1024x768_256 0x105
#define _1024x768_HI 0x117
#define _1024x768_TRUE 0x118

#define _1280x1024_16 0x106
#define _1280x1024_256 0x107
#define _1280x1024_HI 0x11A
#define _1280x1024_TRUE 0x11B

// Return Values
#define BIOSERRNO 255

// Return values of initMode function
#define MODE_NOT_PRESENT 1
#define MODE_NOT_AVAIL 2
#define NON_FATAL 3

// Return value of _doCommon function
#define BIOSCALL_FAILED 4
#define NO_PIXEL_HANDLER 5

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

int isModePresent(unsigned mode);
unsigned logBase2(unsigned n);
int _doCommon(unsigned mode, VgaModeInfoBlock far* b);

int initMode (unsigned mode);
int searchMode(unsigned (* atf)(unsigned, VgaModeInfoBlock far*));

void setPrevMode();
void setTextMode();

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

int isModePresent(unsigned mode)
{
	int i=0;
	VgaInfoBlock vib;

	biosStatus = getSVGAInfo(&vib);
	if(BIOSERR) return 0;				// 0 implies not present

	while(vib.modes[i] != 0xFFFF)
	{
		if(vib.modes[i] == mode) return 1;	// 1 implies present
		i++;
	}

	return 0;
}

/*-------------------------------------------------------------------------*/

unsigned logBase2(unsigned n)
{
	unsigned i=0;

	while(n>1)
	{
		n /= 2;
		i++;
	}

	return i;
}

/*-------------------------------------------------------------------------*/

int _doCommon(unsigned mode, VgaModeInfoBlock far* b)
{
//  Get mode info
	getSVGAModeInfo(b, mode);

//	step 4: intialize global vars
	_granCorrection		=	logBase2 ( 64u/b->windowGranularity );
	_winASeg			=	b->winASegment;
	_winBSeg			=	b->winBSegment;
	_width				=	b->xResolution;
	_pWinFunc			=	b->WinFuncPtr;
	_bytesPerScanLine	=	b->bytesPerScanLine;
	_xRes				=	b->xResolution;
	_yRes				=	b->yResolution;
	_bitsPerPixel		=	b->bitsPerPixel;

//	step 5: store previous mode
	_prevMode = getSVGAMode();		// Not much of a problem if this fails ??!

//	step 6: set SVGA mode
	biosStatus = setSVGAMode(mode);
	if(BIOSERR) return BIOSCALL_FAILED;

//  step 7: Assign Memory window position handlers
		if ( b->WinFuncPtr == 0 )
		{
			_pSetMemWindowPos = &setMemWindowPos_intr;
			_pSetMemWindowPosO = &setMemWindowPos_intrO;
			_pGetMemWindowPos = &getMemWindowPos_intr;
		}

		else
		{
			_pSetMemWindowPos = &setMemWindowPos_ptr;
			_pSetMemWindowPosO = &setMemWindowPos_ptrO;
			_pGetMemWindowPos = &getMemWindowPos_ptr;
		}

//  step 8: Assign putpixel handler
	switch (b->bitsPerPixel)
	{
		case 8:
				pPutPixel = &putPixel256;
				break;

		case 16:
				pPutPixel = &putPixelHI;
				break;

		case 24:
				pPutPixel = &putPixelTRUE;
				break;

		default:
				return NO_PIXEL_HANDLER;
	}

//	step 9: init actPage, _visPage, _wndRPos, _wndWPos, ...
	actPage  = 0;
	_visPage = 0;


//	Dual window system support variables

	switch(b->winBAttributes & 0x01u)
	{
		case 1:						// winB exists
			switch(b->winBAttributes & 0x06u)
			{
				case 6:				// Read Write
					readUsing(winB);
					writeUsing(winB);
					break;

				case 2:				// read only
					readUsing(winB);
					break;

				case 3:				// write only
					writeUsing(winB);
					break;
			}
			break;

		case 0:						// winB does not exist; winA should
			break;
	}

	switch(b->winAAttributes & 0x01u)
	{
		case 1:						// winA exists
			switch(b->winAAttributes & 0x06u)
			{
				case 6:				// Read Write
					readUsing(winA);
					writeUsing(winA);
					break;

				case 2:				// read only
					readUsing(winA);
					break;

				case 3:				// write only
					writeUsing(winA);
					break;
			}
			break;

		case 0:						// winA does not exist; winB should
			break;
	}


	return 0;
}

/*-------------------------------------------------------------------------*/

int initMode(unsigned mode)
{
	VgaModeInfoBlock vmib;

//	step 3: Check wether mode is present
	if(!isModePresent(mode)) return MODE_NOT_PRESENT;

//	step 4: Is mode available currently
	getSVGAModeInfo(&vmib, mode);
	if(!(vmib.modeAttributes & 0x0001)) return MODE_NOT_AVAIL;

	return _doCommon(mode, &vmib);
}

/*-------------------------------------------------------------------------*/

int searchMode(unsigned (* atf)(unsigned, VgaModeInfoBlock far*))
{
	unsigned i=0;
	unsigned mode;
	VgaInfoBlock vib;
	VgaModeInfoBlock vmib;

//  get vgaInfo
	getSVGAInfo(&vib);

//  step1: Call atf with info for each mode

	while(vib.modes[i] != 0xFFFF)
	{
		getSVGAModeInfo(&vmib, vib.modes[i]);

		mode = (*atf)(vib.modes[i], &vmib);
		if( mode != NOT_DECIDED ) goto OtherSteps;		// atf has returned a mode number

		i++;
	}

	mode = (*atf)(FINAL_DECISION, (VgaModeInfoBlock far*)0);// Comes to this point only if a mode number
															// has not been returned
	if ( mode == NOT_DECIDED ) return NOT_DECIDED;			// atf cannot find the required mode

OtherSteps:
	
	return _doCommon(mode, &vmib);
}

void setPrevMode()
{
	setSVGAMode(_prevMode);
}

void setTextMode()
{
	setSVGAMode(0x3);	// 80x25 color mode
}
