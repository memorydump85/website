/***************
*  WRAPPER.H   *
***************/

#define __WRAPPER_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

unsigned _width;
// The logical width of the current mode.

unsigned actPage;
// Set the active page directly using actPage = <page num>
// putPixel actually sets y cordinate as y = actPage*yRes + y

unsigned _visPage;
// Get using getVisiblePage() macro
// Set using setVisiblePage() function

/****************************************************************************
								 MACROS   
****************************************************************************/

#define getVisiblePage() _visPage
// Function like macro equivalent to set counterpart

#define getLogicalWidth() _width
// Function like macro equivalent to set counterpart
// Otherwise BIOS function getScanLineInfo may be used

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

int setVisiblePage(unsigned page);

int setLogicalWidth(unsigned newWidth, LogicalScanLineLenInfo far* info);

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

int setVisiblePage(unsigned page)
{
	_visPage = page;
	return setDisplayStart(0, page*_yRes);		// Return value is the same
												//as the BIOS function
}


/*-------------------------------------------------------------------------*/

int setLogicalWidth(unsigned newWidth, LogicalScanLineLenInfo far* info)
{
	int r;
	
	r = setLogicalScanLineLen(newWidth, info);
	_width = info->pixelsPerScanLine;

	return r;									// Return value is the same
												//as the BIOS function
}
