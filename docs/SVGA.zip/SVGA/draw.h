/***************
*     DRAW.H   *
***************/

#define __DRAW_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

int (* _pSetMemWindowPos)(unsigned, unsigned);
// _pSetMemWindowPos function pointer will point to the function that uses
// interrupts or the one using the _pWinFunc depending upon availability

int (* _pSetMemWindowPosO)();
// _pSetMemWindowPosO function pointer will point to the optimized function
// that uses interrupts or the one using the _pWinFunc depending upon availability

unsigned (* _pGetMemWindowPos)(unsigned char);
// _pGetMemWindowPos function pointer will point to the function that uses
// interrupts or the one using the _pWinFunc depending upon availability

void (* pPutPixel)(unsigned, unsigned, unsigned long);
// pPutPixel function pointer will point to the function that suits the
// current mode in color depth etc.

unsigned _bytesPerScanLine;
// Same value as in VgaModeInfoBlock

unsigned _winRPos, _winWPos;
// Stores the current memory window position, So that window need not
// be moved if it is already in the same position.
//		Set using setMemWindowPos() macro
// * Alternatively values in wndAPos, wndBPos can be read instead	*
// * of calling functions through getMem... macro					*

unsigned _xRes, _yRes;
// Same value as in VgaModeInfoBlock

unsigned _bitsPerPixel;
// Value in VgaModeInfoBlock

/****************************************************************************
								CONSTANTS
****************************************************************************/

// 3D Outline constants

#define _2D_FLAT   0
#define _3D_RAISED 1
#define _3D_INSET  2

#define SHADOW     0

/****************************************************************************
								 MACROS
****************************************************************************/

#define putPixel(x, y, c) (*pPutPixel)(x, y, c)
#define setMemWindowPos(p, w) (*_pSetMemWindowPos)(p, w)
#define setMemWindowPosO() (*_pSetMemWindowPosO)()
#define getMemWindowPos(w) (*_pGetMemWindowPos)(w)

// The above two macros help to look at the code as functions calls
// instead of the more cryptic function pointer dereferencing.
// The macros are redundant in the case of TC++ compiler

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

void waitVRetrace();

void line(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c);
void HLine(unsigned x1, unsigned y1, unsigned x2, unsigned long c);
void VLine(unsigned x1, unsigned y1, unsigned y2, unsigned long c);

void Draw3DOutline(unsigned x1, unsigned y1, unsigned x2, unsigned y2,
				   unsigned long cBR, unsigned long cDK, unsigned char style);

void DrawRectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c);
void FillRectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c);

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

void waitVRetrace()
{
	asm {
		mov dx,0x3DA
	}
l1:
	asm {
		in al,dx
		and al,0x08
		jnz l1
	}

l2:
	asm {
		in al,dx
		and al,0x08
		jz  l2
	}
}

/*-------------------------------------------------------------------------*/

void line(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c)
{

	asm {
		mov cx, [x2]		// Calcualte deltaX
		sub cx, [x1]		// cx = x2 - x1

		mov bx, [y2]		// Calculaye deltaY
		sub bx, [y1]		// bx = y2 - y1

		mov dx, bx			// dx = deltaY
		shl dx, 1			// dx = deltaY * 2	----------------------------|
							//												|
		mov si, dx			// si = deltaY * 2, will be used later			|
							//												|
		sub dx, cx			// dx = (deltaY * 2) - deltaX	<---------------|

		mov di, bx			// di = deltaY
		sub di, cx			// di = deltaY - deltaX
		shl di, 1			// di = 2*(deltaY - deltaX), will be used later

		inc cx				// cx = (x2 - x1) + 1, Number of iterations

	// From now,
	// ax is used to store the value of x
	// bx is used to store the value of y
	// dx is used to store the value of d
	// si = 2 * deltaY
	// di = 2 * ( deltaY - deltaX )
	// cx = Number of iterations

		mov ax, [x1]		// x = x1
		mov bx, [y1]		// y = y1
	}

	StartLoop:				//	<........................................
																	//	:
		// Actual process of drawing the line, uses loop				:
																	//	:
	asm{                                                            //	:
			push ax				// Save values for function call    	:
			push bx				//										:
			push cx             //										:
			push dx				//										:
			push di				//										:
			push si				//										:
	}                            									//  :
																	//	:
	//----------------------------------------							:
		/* C Code */ putPixel(_AX, _BX, c);							//	:
	//----------------------------------------							:
																	//	:
																	//	:
	asm{						//										:
																	//	:
			pop si				// Restore the values of registers										:
			pop di				// after function call										:
			pop dx				//										:
			pop cx				//										:
			pop bx				//										:
			pop ax				//										:
																	//	:
			cmp dx, 0			// To find if d is -ve					:
			jl  LessThanZero	// if d < 0	------------> DECISION		:
								//										:
		// Else					//										:
			add dx, di			// (d =) dx = d + 2 * (deltaY - deltaX)	:
			inc bx				// y++									:
			jmp EndOfDecision	// Skip code for if d<0 block			:
	}							//										:
		LessThanZero:			//										:
								//										:
	asm		add dx, si			// d = d + (2 * deltaY)					:
								//										:
		EndOfDecision:			//										:
								//										:
	asm{						//										:
			inc ax				// x++									:
								//										:
		loop StartLoop			// dec cx; Goto StartLoop if cx > 0	....:
	}
}

/*-------------------------------------------------------------------------*/

void HLine(unsigned x1, unsigned y1, unsigned x2, unsigned long c)
{
	asm		mov si, [x2]		// SI is not used by putPixel routines
								//
l1:								//	<................
	putPixel(x1, y1, c);		//					:
								//					:
	asm {						//					:
			inc [x1]			//					:
			cmp si, [x1]		// Is it the end?   :
			jae l1				// Not yet .........:
	}
}

/*-------------------------------------------------------------------------*/

void VLine(unsigned x1, unsigned y1, unsigned y2, unsigned long c)
{
	asm		mov si, [y2]		// SI is not used by putPixel routines
								//
l1:								//	<................
	putPixel(x1, y1, c);		//					:
								//					:
	asm {						//					:
			inc [y1]			//					:
			cmp si, [y1]		// Is it the end?   :
			jae l1				// Not yet .........:
	}
}

/*-------------------------------------------------------------------------*/

void Draw3DOutline(unsigned x1, unsigned y1, unsigned x2, unsigned y2,
				   unsigned long cBR, unsigned long cDK, unsigned char style)
{

	switch(style)
	{
		case _3D_RAISED:

		// Top Left

			HLine(x1, y1, x2, cBR);
			VLine(x1, y1, y2, cBR);

			asm {
					inc [x1]	// x1++
					inc [y1]    // y1++
			}

		// Bottom Right

			HLine(x1, y2, x2, cDK);
			VLine(x2, y1, y2, cDK);

			asm {
					inc [x1]	// x1++
					inc [y1]    // y1++
					inc [x2]	// x2++
					inc [y2]    // y2++
			}

		// Shadow

			HLine(x1, y2, x2, SHADOW);
			VLine(x2, y1, y2, SHADOW);

			break;

		case _3D_INSET:

		// Top Left

			HLine(x1, y1, x2, cDK);
			VLine(x1, y1, y2, cDK);

			asm {
					inc [x1]	// x1++
					inc [y1]    // y1++
			}

		// Bottom Right

			HLine(x1, y2, x2, cBR);
			VLine(x2, y1, y2, cBR);

			asm {
					sub [x1], 2	// x1++
					sub [y1], 2 // y1++
					dec [x2]	// x2++
					dec [y2]    // y2++
			}

		// Shadow

			HLine(x1, y1, x2, SHADOW);
			VLine(x1, y1, y2, SHADOW);

			break;

		case _2D_FLAT:

		// Top Left

			HLine(x1, y1, x2, cDK);
			VLine(x1, y1, y2, cDK);

			asm {
					inc [x1]	// x1++
					inc [y1]    // y1++
			}

		// Bottom Right

			HLine(x1, y2, x2, cBR);
			VLine(x2, y1, y2, cBR);

			asm {
					inc [x1]	// x1++
					inc [y1]    // y1++
					inc [x2]	// x2++
					inc [y2]    // y2++
			}

		// Shadow

			HLine(x1, y2, x2, cDK);
			VLine(x2, y1, y2, cDK);

			break;
	}

}

/*-------------------------------------------------------------------------*/

void DrawRectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c)
{
	HLine(x1, y1, x2, c);
	VLine(x1, y1, y2, c);

	asm {
			inc [x1]	// x1++
			inc [y1]    // y1++
	}

	HLine(x1, y2, x2, c);
	VLine(x2, y1, y2, c);
}

/*-------------------------------------------------------------------------*/

void FillRectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, unsigned long c)
{
	unsigned x, y;

	x = x1;
	y = y1;

again:                      // 	<................................
							//              :                   :
		putPixel(x, y, c);  //              :                   :
							//              :                   :
	asm {                   //              :                   :
			inc [x]			// x++          :                   :
			mov ax, [x2]    //              :                   :
			cmp ax, [x]     // Is x2 >= x   :                   :
			jae again       // if so .......:                   :
							//                                  :
							// -------------Inner Loop ends     :
							//                                  :
			mov ax, [x1]	// ax = x1                          :
			mov [x], ax		// x  = x1                          :
			inc [y]			// y++                              :
			mov ax, [y2]	//                                  :
			cmp ax, [y]		// Is y2 >= y                       :
			jae again		// if so ...........................:
	}
}