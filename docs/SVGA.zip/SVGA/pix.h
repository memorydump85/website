/***************
*      PIX.H   *
***************/

#define __PIX_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

unsigned char transparency;
unsigned scale=1;			// =1 (By external declaration in Global.h)
float rotation;
// putPixel handlers use the above variables to apply transformations
// to the point being plotted

unsigned char _granCorrection;
// The correction for considering all granularities as 64K
// For example 4K can be considered as 64K by shifiting the window
// 16 times instead of once. 16 is 2^4;
// and x*16 = x << 4, then _granCorrection = 4;

unsigned _winASeg, _winBSeg;
// Segment of memory windows usually 0xA000 and/or 0xB000

unsigned _winWSeg, _winRSeg;
// Segments of memory window used for reading and writing
// respectively

unsigned _winWNum, _winRNum;
// Number of the memory window used for reading and writing
// respectively

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

void putPixel256(unsigned x, unsigned y, unsigned long c);
void putPixelHIGH(unsigned x, unsigned y, unsigned long c);
void putPixelTRUE(unsigned x, unsigned y, unsigned long c);

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

// The following putPixel routines preserve the values in SI


void putPixel256(unsigned x, unsigned y, unsigned long c)
{
	asm{
		// STEP 1

			// Calculate actPage * yRes

				mov ax, [actPage]	//
				mul [_yRes]			// The result is dx:ax
									// But the result will fit into ax alone
									// So result = ax

			// Calculate (actPage * yRes) + y

				add ax, [y]		// Result is ax

			// Calculate ((actPage * yRes) + y) * width

				mul [_width]	// Result is a DWORD in dx:ax

			// Calculate (((actPage * yRes) + y) * xRes) + x

				add ax, [x]		// Add to lower order word Results in a carry
				adc dx, 0		// Add carry to higher order word

		// STEP 2

			// Multiply by number of bytes per color
			// The final result is in ** DX:DI **
			// 	For 8bit modes multiply by one or Just copy ax to di

				mov di, ax		// Result is in dx:di

		// STEP 3

			// dx is the memory window position
			// di is the offset in to the window

			// Correction for Granularity

				mov cl, [_granCorrection]	// SHL cannot use vars directly
				shl dx, cl					//

	}

	// Set Memory window position after comparison

	asm{
				cmp dx, [_winWPos]	// Is current position same as required?
				je  NoMove256		// If so just carry on	.........
									//								:
				mov bx, [_winWNum]	// Required window				:
	}								//								:
				setMemWindowPosO();	// Optimized routine			:
									//								:
	asm			mov [_winWPos], dx	//								:
									//								:
NoMove256:							// <............................:

	asm{
		//  STEP 4

			// Setup es

				mov es, [_winWSeg]	// es = window Segment

			// Move value into offset given by di
			//	For 8bit modes move 1 byte

				mov al, BYTE PTR [c]	// Move color value into al
				mov es:[di], al			// Store 1 byte of color at offset
										// Faster than using stos on 286+
	}

}

/*-------------------------------------------------------------------------*/

void putPixelHI(unsigned x, unsigned y, unsigned long c)
{
	asm{
		// STEP 1

			// Calculate actPage * yRes

				mov ax, [actPage]	//
				mul [_yRes]			// The result is dx:ax
									// But the result will fit into ax alone
									// So result = ax

			// Calculate (actPage * yRes) + y

				add ax, [y]		// Result is ax

			// Calculate ((actPage * yRes) + y) * width

				mul [_width]	// Result is a DWORD in dx:ax

			// Calculate (((actPage * yRes) + y) * xRes) + x

				add ax, [x]		// Add to lower order word Results in a carry
				adc dx, 0		// Add carry to higher order word

		// STEP 2

			// Multiply by number of bytes per color
			// The final result is in ** DX:DI **
			// 	For 16bit modes multiply by 2 or shift dx:ax left by 1

				shl dx, 1		// Bit number 0 (LSB) is 0
				shl ax, 1		// The bit shifted out is in the Carry Flag
				adc dx, 0		// The value in the carry flag is inserted in
								// dx because Bit0(=0) + CF = CF !
				mov di, ax		// Result is in dx:di

		// STEP 3

			// dx is the memory window position
			// di is the offset in to the window

			// Correction for Granularity

				mov cl, [_granCorrection]	// SHL cannot use vars directly
				shl dx, cl					//

	}

	// Set Memory window position after comparison

	asm{
				cmp dx, [_winWPos]	// Is current position same as required?
				je  NoMoveHI		// If so just carry on	.........
									//								:
				mov bx, [_winWNum]	// Required window				:
	}								//								:
				setMemWindowPosO();	// Optimized routine			:
									//								:
	asm			mov [_winWPos], dx	//								:
									//								:
NoMoveHI:							// <............................:

	asm{
		//  STEP 4

			// Setup es

				mov es, [_winWSeg]	// es = window Segment

			// Move value into offset given by di
			//	For 16bit modes move 1 word

				mov ax, WORD PTR [c]	// Move color value into ax
				mov es:[di], ax			// Store 1 word of color at offset
	}

}

/*-------------------------------------------------------------------------*/

void putPixelTRUE(unsigned x, unsigned y, unsigned long c)
{
	asm{
		// STEP 1

			// Calculate actPage * yRes

				mov ax, [actPage]	//
				mul [_yRes]			// The result is dx:ax
									// But the result will fit into ax alone
									// So result = ax

			// Calculate (actPage * yRes) + y

				add ax, [y]		// Result is ax

			// Calculate ((actPage * yRes) + y) * width

				mul [_width]	// Result is a DWORD in dx:ax

			// Calculate (((actPage * yRes) + y) * xRes) + x

				add ax, [x]		// Add to lower order word Results in a carry
				adc dx, 0		// Add carry to higher order word

		// STEP 2

			// Multiply by number of bytes per color
			// The final result is in ** DX:DI **
			// 	For 24bit modes multiply by 3 or (2+1)
			//		or use the operation DX:DI = DX:AX<<1 + DX:AX

				mov di, ax		//
				mov cx, dx		// cx:di = dx:ax

			// Multiply by 2

				shl dx, 1		// Bit number 0 (LSB) is 0
				shl ax, 1		// The bit shifted out is in the Carry Flag
				adc dx, 0		// The value in the carry flag is inserted in
								// dx because Bit0(=0) + CF = CF !
								// Now dx:ax = original dx:ax * 2

			// Multiply by 3 = dx:ax + dx:ax << 1 (i.e Now) dx:ax + cx:di
			// Result is stored in dx:di

				add di, ax		// Add lower order words
				adc dx, cx		// Add higher order words with carry
								// ** Result is dx:di **
		// STEP 3

			// dx is the memory window position
			// di is the offset in to the window

			// Correction for Granularity

				mov cl, [_granCorrection]	// SHL cannot use vars directly
				shl dx, cl					//

	}

	// Set Memory window position after comparison

	asm{
				cmp dx, [_winWPos]	// Is current position same as required?
				je  NoMoveTR		// If so just carry on	.........
									//								:
				mov bx, [_winWNum]	// Required window				:
	}								//								:
				setMemWindowPosO();	// Optimized routine			:
									//								:
	asm			mov [_winWPos], dx	//								:
									//								:
NoMoveTR:							// <............................:

	asm{
		//  STEP 4

			// Setup es

				mov es, [_winWSeg]	// es = window Segment

			// Move value into offset given by di
			//	For 24bit modes move 3 bytes = 1 word + 1 byte

			// Check wether offset is 0xFFFE or 0xFFFF and take necessary action
				
				cmp di, 0xFFFE		// Flags are set accordingly
				je  AlmostEdge		// Jump if equal to 0xFFFE to AlmostEdge:
				ja  AtEdge			// Jump if equal to 0xFFFF to AtEdge:

			// ---------------------------------------------------------------------NOJMP

			// When offset is < 0xFFFE

				mov ax, WORD PTR [c]	// Move 1st 2 bytes of color value into ax
				mov es:[di], ax			// Store 1 word of color at offset
				mov al, BYTE PTR [c+2]  // Move 3rd byte of color into al
				mov es:[di+2], al		// Store 1 byte of color at offset

				jmp Finish				// Like break for a switch

	}
AlmostEdge: // -------------------------------------------------------------JMP=

	asm{
			// When offset is 0xFFFE

				mov ax, WORD PTR [c]	// Move 1st 2 bytes of color value into ax
				mov es:[di], ax			// Store 1 word of color at offset
				inc dx					// The next byte can be accessed only by moving
										// the CPU memory window
	}

	// Set Memory window position after comparison

	asm{
				cmp dx, [_winWPos]	// Is current position same as required?
				je  NoMoveTRa		// If so just carry on	.........
									//								:
				mov bx, [_winWNum]	// Required window				:
	}								//								:
				setMemWindowPosO();	// Optimized routine			:
									//								:
	asm			mov [_winWPos], dx	//								:
									//								:
NoMoveTRa:							// <............................:

	asm{
				mov al, BYTE PTR [c+2]  // Move 3rd byte of color into al
				mov es:[di+2], al		// Store 1 byte of color at offset
										// DI is made 0 automatically

				jmp Finish				// Like break for a switch

	}
AtEdge:	// ----------------------------------------------------------------JMP>

	asm{
			// When offset is 0xFFFF

				mov al, BYTE PTR [c]	// Move 1st byte of color value into al
				mov es:[di], al			// Store 1 byte of color at offset
				inc dx					// The next byte can be accessed only by moving
										// the CPU memory window

	}

	// Set Memory window position after comparison

	asm{
				cmp dx, [_winWPos]	// Is current position same as required?
				je  NoMoveTRb		// If so just carry on	.........
									//								:
				mov bx, [_winWNum]	// Required window				:
	}								//								:
				setMemWindowPosO();	// Optimized routine			:
									//								:
	asm			mov [_winWPos], dx	//								:
									//								:
NoMoveTRb:							// <............................:

	asm{
				mov ax, WORD PTR [c+1]  // Move last 2 bytes of color into ax
				mov es:[di+1], ax		// Store 2 bytes of color at offset
										// DI is made 0 automatically
	}

Finish:
}