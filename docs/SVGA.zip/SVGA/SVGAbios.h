/***************
* SVGABIOS.H   *
***************/

#ifndef __DOS_H
	#include <dos.h>
#endif

#ifndef __STRUCTS_H
	#include "structs.h"
#endif

#define __SVGABIOS_H

/****************************************************************************
							GLOBAL VARIABLES
****************************************************************************/

//	Return values of the bios stored in AX are not returned
//	by some functions. Then the value in AX is stored in
//	the global variable 'biosStatus'.

	unsigned biosStatus;

//  Values in biosStatus:
//		low byte  == 4Fh:      Function is supported
//		low byte  != 4Fh:      Function is not supported
//		high byte == 00h:      Function call successful
//		high byte == 01h:      Function call failed

/****************************************************************************
								CONSTANTS
****************************************************************************/

// To be used with setSVGAMode()
#define CLEAR 0x8000

// 0x4F is the value  in AX when there is no error after an interrupt
#define NOBIOSERR 0x4F
#define BIOSERR biosStatus!=NOBIOSERR	

// save,restore SVGA state constants
#define ST_HARDWARE 1
#define ST_BIOSDATA 2
#define ST_DAC 4
#define ST_SVGA 8

/****************************************************************************
						   FUNCTION PROTOTYPES
****************************************************************************/

int getSVGAInfo(VgaInfoBlock far* b);
int getSVGAModeInfo(VgaModeInfoBlock far* b, unsigned int modeNumber);

int setSVGAMode(int mode);
int getSVGAMode();

int getSVGAStateBufferLen(unsigned states);
int saveSVGAState(char far* buffer, unsigned states);
int restoreSVGAState(char far* buffer, unsigned states);

int setMemWindowPos_intr(unsigned pos, unsigned window);
unsigned getMemWindowPos_intr(unsigned char window);

int setLogicalScanLineLen(unsigned newWidth, LogicalScanLineLenInfo far* info);
int getScanLineInfo(LogicalScanLineLenInfo far* info);

int setDisplayStart(unsigned x, unsigned y);
int getDisplayStart(unsigned far* x, unsigned far* y);

int setDAC(unsigned char bits);
int getDAC();

// For more information on the above functions read the file
//			VESASP12.TXT

/****************************************************************************
						  FUNCTION DEFINITIONS
****************************************************************************/

int getSVGAInfo(VgaInfoBlock far* b)
{
	_AX = 0x4F00;
	_ES = FP_SEG(b);
	_DI = FP_OFF(b);
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

int getSVGAModeInfo(VgaModeInfoBlock far* b, unsigned int modeNumber)
{
	_AX = 0x4F01;
	_CX = modeNumber;
	_ES = FP_SEG(b);
	_DI = FP_OFF(b);
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

int setSVGAMode(int mode)
{
	_AX = 0x4F02;
	_BX = mode;			// use mode|CLEAR to clear video memory
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

int getSVGAMode()
{
	_AX = 0x4F03;
	geninterrupt(0x10);

	biosStatus = _AX;
	return _BX;
}

/*-------------------------------------------------------------------------*/

int getSVGAStateBufferLen(unsigned states)
{
	_AX = 0x4F04;
	_DL = 0x00;
	_CX = states;
	geninterrupt(0x10);

	biosStatus = _AX;	
	return _BX*64;
}

/*-------------------------------------------------------------------------*/

int saveSVGAState(char far* buffer, unsigned states)
{
	_AX = 0x4F04;
	_DL = 0x01;
	_CX = states;
	_ES = FP_SEG(buffer);
	_BX = FP_OFF(buffer);
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

int restoreSVGAState(char far* buffer, unsigned states)
{
	_AX = 0x4F04;
	_DL = 0x02;
	_CX = states;
	_ES = FP_SEG(buffer);
	_BX = FP_OFF(buffer);
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

#pragma warn -rvl

int setMemWindowPos_intr(unsigned pos, unsigned window)
{

// This routine is in assembly for performance
// reasons

	asm {
			mov ax, 0x4F05		// Interrupt requirements
			mov bx, [window]	// bh = 0, bl = window
								// That is why window is an uint here
			mov dx, [pos]       // requirement
			int 0x10            // generate interrupt
	}
								// Value in ax is automatically returned
}

#pragma warn -rvl

/*-------------------------------------------------------------------------*/

unsigned getMemWindowPos_intr(unsigned char window)
{
	_AX = 0x4F05;
	_BH = 1;
	_BL = window;
	geninterrupt(0x10);

	biosStatus = _AX;
	return _DX;
}

/*-------------------------------------------------------------------------*/

int setLogicalScanLineLen(unsigned newWidth, LogicalScanLineLenInfo far* info)
{
	_AX = 0x4F06;
	_BL = 0x00;
	_CX = newWidth;
	geninterrupt(0x10);

	info->bytesPerScanLine = _BX;
	info->pixelsPerScanLine = _CX;
	info->maxScanLines = _DX;

	return _AX;
}

/*-------------------------------------------------------------------------*/

int getScanLineInfo(LogicalScanLineLenInfo far* info)
{
	_AX = 0x4F06;
	_BL = 0x01;
	geninterrupt(0x10);

	info->bytesPerScanLine = _BX;
	info->pixelsPerScanLine = _CX;
	info->maxScanLines = _DX;

	return _AX;
}

/*-------------------------------------------------------------------------*/

int setDisplayStart(unsigned x, unsigned y)
{
	_AX = 0x4F07;
	_BX = 0x0000;
	_CX = x;
	_DX = y;
	geninterrupt(0x10);

	return _AX;
}

/*-------------------------------------------------------------------------*/

int getDisplayStart(unsigned far* x, unsigned far* y)
{
	_AX = 0x4F07;
	_BL = 0x01;
	geninterrupt(0x10);

	*x = _CX;
	*y = _DX;

	return _AX;
}

/*-------------------------------------------------------------------------*/

int setDAC(unsigned char bits)
{
	_AX = 0x4F08;
	_BL = 0x00;
	_BH = bits;
	geninterrupt(0x10);

	biosStatus = _AX;
	return _BH;
}

/*-------------------------------------------------------------------------*/

int getDAC()
{
	_AX = 0x4F08;
	_BL = 0x01;
	geninterrupt(0x10);

	biosStatus = _AX;
	return _BH;
}

