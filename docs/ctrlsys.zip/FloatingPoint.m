function [ output_args ] = GAReduc( hnum, hden )
%GAREDUC - reduces the system to 2nd order uses evolutionary tuning on the reduction
%USAGE:
%
%   GAREDUC(numerator-poly, denominator-poly)
%
%   Reduces system to second order by the coefficient-averaging method and calculates
%   zeta-n and omega-n from the estimate. It then builds an initial reduction by the
%   transient response and DCGain data and the calculated values. Then it uses
%   evolutionary search for an optimal approximation.
    
% Average of coefficients reduction
    t = hden; t1 = [];
   
    for I = length(hden):-1:4,
        for J = 1:I-1,
            t1(J) = (t(J) + t(J+1))/2;  %take average
        end
        t = t1;
        if I~=4,
           t1 = []; % we need the last value
        end
    end
    
    t1 = t1./t1(1); % normalize the values i.e. divide by c
    omega = sqrt(t1(3)); % Wn - Omega n
    zeta = t1(2)/(2*omega); % 3n - Zeta n
    
% free up some memory
    clear t, t1;
    
    transientRatio = hnum(1)/hden(1);
    dcGainRatio = hnum(length(hnum))/hden(length(hden));
    
%The initial reduction is by default erratic so we donot actually
%consider it
%    initRedNum = [transientRatio dcGainRatio*omega*omega];
%    initRedDen = [1 2*zeta*omega omega*omega];
    
    popSize = 10;
    
% create a population by slightly changing the values of zeta & omega
   for I=1:popSize,
       tempOmega = omega + ((rand - 0.5)*2);
       %tempZeta = zeta + ((rand - 0.5)*2)*2;
       tempZeta = zeta + rand*2;
       
       popNum(I,:) = [transientRatio dcGainRatio*tempOmega*tempOmega];
       popDen(I,:) = [1 2*tempZeta*tempOmega tempOmega*tempOmega];
   end

   time = 0:.1:10;

% free memory
%    clear tempOmega, tempZeta;
    
% step response of initial system
   yOrg = step(hnum,hden, time)';    
    
   for G = 0:75,
    % Display population and calculate errors
        clf;
        plot(time,yOrg,'r');
        hold on;
	
        for I=1:size(popNum,1),
            y(I,:) = step(popNum(I,:),popDen(I,:), time)';
            plot(time,y(I,:), 'g:');
        end
        
        abserr = sum(abs(ones(size(popNum,1),1)*yOrg - y), 2)';
        
	% Show the best solution found in a different color
        [val, minIndex] = min(abserr);  % find min (and its index)
        plot(time, step(popNum(minIndex,:), popDen(minIndex,:), time)', 'b');
        
    %crossover:
        [p1, p2] = roulette_select(1 ./ abserr);    % fitness is inversely proportional to error

    % if population has reached its limit replace least fit, else just add a new individual
        [val, maxIndex] = max(abserr);  % find max (and its index)
        if(size(popNum,1) < popSize),
            maxIndex = size(popNum,1) + 1;
        end

    % form child by averaging
        popNum(maxIndex,:) = (popNum(p1,:) + popNum(p2,:))./ 2;  % average
        popDen(maxIndex,:) = (popDen(p1,:) + popDen(p2,:))./ 2;  % average
        
        pause(0.1);
    end
    
% NOTE: The results of the last generation have not been updated. So the minimum is the
%       value of the best solution in the last but one generation.
    
    [val, minIndex] = min(abserr);  % find min (and its index)
    tf(popNum(minIndex,:), popDen(minIndex,:))  % display solution
   
    hold off;

%---------------------------------------------------------------------------------------------------
        
function [index1, index2] = roulette_select(v)
    cum = cumsum(v);
    r = rand * cum(length(cum));
    index1 = find(cum >= r);
    index1 = index1(1);
    
% remove unwanted index1 to avoid reselection
    if index1==0
        w = v(2:length(v));
    elseif index1==length(v)
        w = v(1:(length(v)-1));
    else
        w = [ v(1:(index1-1)) v((index1+1):length(v)) ];
    end
    
    cum = cumsum(w);
    r = rand * cum(length(cum));
    index2 = find(cum >= r);
    index2 = index2(1);    
