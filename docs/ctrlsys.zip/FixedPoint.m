function [ ret ] = FixedPoint( hnum, hden )
%FIXEDPOINT - reduces the system to 2nd order uses evolutionary tuning
%USAGE:
%
%   FIXEDPOINT(numerator-poly, denominator-poly)
%
%   Reduces system to second order by searching for appropriate values
%   of omega-n and zeta-n using a genetic algorithm operating on a
%   fixed point representation. It first creates an approximation of
%   omega-n and zeta-n using an averaging algorithm and searches
%   points near this initial estimate of omega-n and zeta-n

% Average of coefficients reduction
    t = hden; t1 = [];
    global nbits;
    nbits = 16;
   
    for I = length(hden):-1:4,
        for J = 1:I-1,
            t1(J) = (t(J) + t(J+1))/2;  %take average
        end
        t = t1;
        if I~=4,
           t1 = []; % we need the last value
        end
    end
    
    t1 = t1./t1(1); % normalize the values i.e. divide by c
    omega = sqrt(t1(3)) % Wn - Omega n
    zeta = t1(2)/(2*omega) % 3n - Zeta n
    
% free up some memory
    clear t, t1;
    
    transientRatio = hnum(1)/hden(1);
    dcGainRatio = hnum(length(hnum))/hden(length(hden));
       
    popSize = 80;
    time = 0:.1:10;
% step response of initial system
    yOrg = step(hnum,hden, time)';    

% create intitial population
    for I=1:popSize,
        popBitZeta(I,:) = rand(1,16) > 0.5;
        % Uncomment following lines to search everywhere; not
        % just around the initial estimates
        ZetaAdjust = frac2bitvec(abs(zeta+(rand-0.5)*0.3), nbits);
        popBitZeta(I,:) = ZetaAdjust;
        
        popBitOmega(I,:) = rand(1,16) > 0.5;
        % Uncomment following lines to search everywhere; not
        % just around the initial estimates      
        OmegaAdjust = num2bitvec(fix(abs(omega+(rand-0.5)*5)), 6);
        popBitOmega(I,1:6) = OmegaAdjust;
    end

    disp('initial population:');
    for I=1:popSize
        fprintf('%d', popBitZeta(I,:));
        fprintf(' : %f, ', bitvec2frac(popBitZeta(I,:), nbits));
        fprintf('%d', popBitOmega(I,:));
        fprintf(' : %f', bitvec2fix(popBitOmega(I,:), nbits));        
        fprintf('\n');
    end
    
    for I=1:popSize,
        tempZeta = bitvec2frac(popBitZeta(I,:), nbits);
        tempOmega = bitvec2fix(popBitOmega(I,:), nbits);
        y(I,:) = stepforZW(tempZeta, tempOmega, transientRatio, dcGainRatio, time)';
    end

    for G = 1:200,
        clf;

    % display original response
    %    figure(2);
        plot(time, yOrg, 'r');
        hold on;
        
        abserr = sum(abs(ones(size(popBitZeta,1),1)*yOrg - y), 2)';
        
	% Show the best solution found in a different color
        [val, minIndex] = min(abserr);  % find min (and its index)
        tempZeta = bitvec2frac(popBitZeta(minIndex,:), nbits);
        tempOmega = bitvec2fix(popBitOmega(minIndex,:), nbits);
        plot(time, stepforZW(tempZeta, tempOmega, transientRatio, dcGainRatio, time)', 'b');
        
    % print the best
        tf( [transientRatio dcGainRatio*tempOmega*tempOmega], [1 2*tempZeta*tempOmega tempOmega*tempOmega] )
        
        if (max(abserr)-min(abserr)) < 0.1    % if population has almost converged
            disp(' --Search terminated prematurely due to convergence--');
            break;
        end
        
        fprintf('Gen: %d    zeta: %f    omega: %f   pi:%f   min:%d\n', fix(G), tempZeta, tempOmega, abserr(minIndex), minIndex);
        
    % crossover:
         [p1, p2] = roulette_select(1 ./ abserr);    % fitness is inversely proportional to error
         
         [c1Z, c2Z] = crossover(popBitZeta(p1,:), popBitZeta(p2,:));
         [c1W, c2W] = crossover(popBitOmega(p1,:), popBitOmega(p2,:));
         
    % mutation: < 0.1 leads to rate pm = 0.01
        for I=1:nbits,
            if rand < 0.1
                c1Z(I) = mod(c1Z(I)+1, 2);
            end
            if rand < 0.1
                c2Z(I) = mod(c2Z(I)+1, 2);
            end                    
        end
        for I=1:nbits,
            if rand < 0.1
                c1W(I) = mod(c1W(I)+1, 2);
            end
            if rand < 0.1
                c2W(I) = mod(c2W(I)+1, 2);
            end                    
        end
         
	% replace worst two
        [val, minIndex] = sort(abserr);
        worst1 = minIndex(length(minIndex));
        worst2 = minIndex(length(minIndex)-1);
        
        popBitZeta(worst1, :) = c1Z;
        popBitZeta(worst2, :) = c2Z;
        popBitOmega(worst1, :) = c1W;
        popBitOmega(worst2, :) = c2W;

    % update y values
        for I = [worst1, worst2],
            tempZeta = bitvec2frac(popBitZeta(I,:), nbits);
            tempOmega = bitvec2fix(popBitOmega(I,:), nbits);
            y(I,:) = stepforZW(tempZeta, tempOmega, transientRatio, dcGainRatio, time)';
        end
        
        pause(0.1);
    end
    
    disp('population at termination:');
    for I=1:popSize
        fprintf('%d', popBitZeta(I,:));
        fprintf(' : %f, ', bitvec2frac(popBitZeta(I,:), nbits));
        fprintf('%d', popBitOmega(I,:));
        fprintf(' : %f', bitvec2fix(popBitOmega(I,:), nbits));        
        fprintf('\n');
    end
       
%---------------------------------------------------------------------------------------------------

function [v] = num2bitvec(n, nbits)
    v = zeros(1,nbits);

    for I=1:nbits,
        v(nbits-I+1) = bitget(n,I);
    end

%---------------------------------------------------------------------------------------------------

function [v] = frac2bitvec(f, nbits)
    v = zeros(1, nbits);

    for I=1:nbits,
        f = f*2;
        v(I) = floor(f);
        f = abs(floor(f) - f);
    end

%---------------------------------------------------------------------------------------------------

function [n] = bitvec2frac(v, nbits)
    n=0;

    for I=1:nbits,
        n = n+(2^(-I) * v(I));
    end

%---------------------------------------------------------------------------------------------------

 function [n] = bitvec2fix(v, nbits)
    n=0;

    for I=1:nbits,
        n = n+(2^(6-I) * v(I)); % Maximum of 32 as there as 5 bits before the decimal point
    end
    
%---------------------------------------------------------------------------------------------------
function [y] = stepforZW(Zeta, Omega, trans, dcg, time)
    Num = [trans dcg*Omega*Omega];
    Den = [1 2*Zeta*Omega Omega*Omega];

    tfn = tf(Num,Den);
    y = step(tfn, time);
    
%---------------------------------------------------------------------------------------------------
        
function [index1, index2] = roulette_select(v)
    cum = cumsum(v);
    r = rand * cum(length(cum));
    index1 = find(cum >= r);
    index1 = index1(1);
    
% remove unwanted index1 to avoid reselection
    if index1==0
        w = v(2:length(v));
    elseif index1==length(v)
        w = v(1:(length(v)-1));
    else
        w = [ v(1:(index1-1)) v((index1+1):length(v)) ];
    end
    
    cum = cumsum(w);
    r = rand * cum(length(cum));
    index2 = find(cum >= r);
    index2 = index2(1);    
    
%---------------------------------------------------------------------------------------------------

function [c1, c2] = crossover(p1, p2)
    nbits = length(p1);
    point = fix(rand * nbits);
     c1 = p1;
     c2 = p2;
     c2(point+1:nbits) = p1(point+1:nbits);
     c1(point+1:nbits) = p2(point+1:nbits);
